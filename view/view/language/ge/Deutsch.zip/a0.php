<?php
/*
------------------
Language: German
------------------
*/

// � = &#220
// � = &#252
// � = &#214
// � = &#246
// � = &#196
// � = &#228
// � = &#223
// � = &#167
// � = &#128

$lang = array();

require('menue_includes/top_menue.php');

$lang['B0']          = 'home';
$lang['C3_1_header'] = 'Vision';
$lang['C3_1_1']      = 'Skolenet erm&#246glicht Mitgliedern eine webbasierte Zusammenarbeit einer Schule oder innerhalb einer Arbeitsgruppe von mehreren Schulen. Skolenet ist ein soziales Netzwerk und hilft Verbindungen in einer Gruppe zu vertiefen, den Kontakt mit den &#252brigen Mitgliedern einer Gruppe zu halten oder einfach Informationen unter Gruppenmitgliedern auszutauschen. Skolenet verbindet die Vorteile eines Intranet Systems mit den Vorteilen eines sozialen Netzwerkes. Die Datensicherheit von Informationen kombiniert mit der M&#246glichkeit Informationen in Gruppen einfach auszutauschen. Ein interner mobbing Filter rundet den Sicherheitsgedanken ab.';
$lang['C3_1_2']      = '';
$lang['C3_2_header'] = 'Mission';
$lang['C3_2_1']      = 'Skolenet ist ein privates soziales Netzwerk f&#252r Schulen. Skolenet ist gruppenorientiert und unterst&#252tzt Projektarbeit, die fach&#252bergreifend, klassen&#252bergreifend, schul&#252bergreifend oder auch l&#228nder&#252bergreifend sein kann. Die Struktur einer Schule kann dynamisch im System nachgebildet werden. Das Ziel von Skolenet ist keine einseitige Kommunikation, es ist ein gegenseitiger Austausch von Informationen jeglicher Art. Die Hauptziele sind:';
$lang['C3_2_2']      = '<ul><li>einfach Informationen zu verteilen</li><li>einfach an Informationen zu gelangen</li><li>einfach Informationen zu sichern</li></ul>';
$lang['C3_2_3']      = '';
?>