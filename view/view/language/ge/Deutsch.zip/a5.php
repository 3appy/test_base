<?php
/*
------------------
Language: German
------------------
*/

// � = &#220
// � = &#252
// � = &#214
// � = &#246
// � = &#196
// � = &#228
// � = &#223
// � = &#167
// � = &#128

$lang = array();

require('menue_includes/top_menue.php');

$lang['B0']          = 'home';
$lang['C3_1_header'] = 'Impressum';
$lang['C3_1']        = "Angaben gem&#228&#223 &#167 5 TMG:<br/><br/>";
$lang['C3_2']        = "Bernd Schr&#246der<br />Geestbogen 76<br />24941 Flensburg<br />";
$lang['C3_2_header'] = 'Kontakt';
$lang['C3_3']        = "Telefon: 0045 5153829<br />E-Mail: Customer-Support@skolenet.de";
?>

